"""
This package allows for bin counting to form histograms.
"""
from . import freedman_diaconis
from .base import counts
